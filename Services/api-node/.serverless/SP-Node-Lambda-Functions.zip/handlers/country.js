// Import your centralized DynamoDB client
const { client } = require("../db/dynamo.client");
const { ScanCommand } = require("@aws-sdk/lib-dynamodb");

// Table name from environment variable
const TABLE = process.env.CountryTable;

exports.get = async (event) => {
  try {
    const result = await client.send(new ScanCommand({ TableName: TABLE }));
    return {
      statusCode: 200,
      body: JSON.stringify({
        countries: result.Items.sort((a, b) => a.countryId - b.countryId),
      }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Could not fetch countries" }),
    };
  }
};
